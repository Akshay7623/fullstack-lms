import { useState } from "react";
import { Button, Stack } from "@mui/material";
import Breadcrumbs from "components/@extended/Breadcrumbs";
import PendingPayments from "./payments/PendingPayments";
import SettledPayments from "./payments/SettledPayments";

const TrainerPayment = () => {
  const [selected, setSelected] = useState("pending");

  const breadcrumbLinks = [
    { title: "trainers", to: "/trainers/list" },
    { title: "trainer-payments" },
  ];

  return (
    <>
      <Breadcrumbs custom heading="trainer-payments" links={breadcrumbLinks} />
      <Stack direction="row" spacing={2} sx={{ mb: 3 }}>
        <Button
          variant={selected === "pending" ? "contained" : "outlined"}
          color="warning"
          onClick={() => setSelected("pending")}
        >
          Pending
        </Button>
        <Button
          variant={selected === "settled" ? "contained" : "outlined"}
          color="primary"
          onClick={() => setSelected("settled")}
        >
          Settled
        </Button>
      </Stack>

      {selected === "pending" && <PendingPayments />}
      {selected === "settled" && <SettledPayments />}
    </>
  );
};

export default TrainerPayment;

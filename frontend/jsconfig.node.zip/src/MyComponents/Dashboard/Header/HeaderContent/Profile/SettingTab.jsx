import { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router';

// material-ui
import List from '@mui/material/List';
import Link from '@mui/material/Link';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import { useEmailPreference } from "../../../../../contexts/EmailPreferenceContext";


// assets
import { Clipboard, Lock1, Messages1, Profile, Timer1 } from 'iconsax-react';
import { FormControlLabel, Switch } from '@mui/material';

// ==============================|| HEADER PROFILE - SETTING TAB ||============================== //

export default function SettingTab() {
  const navigate = useNavigate();
  const { pathname } = useLocation();

  const { settings, updatePreferences } = useEmailPreference();

  //   emailOnTimeChange: true,
  //   emailOnTrainerAssign: true,
  //   emailOnLectureCancel: true,
  //   emailOnLectureReschedule: true,

  const [selectedIndex, setSelectedIndex] = useState();
  const handleListItemClick = (event, index, route = '') => {
    setSelectedIndex(index);
    if (route && route !== '') {
      navigate(route);
    }
  };

  useEffect(() => {
    const pathToIndex = {
      '/apps/profiles/account/settings': 1
    };

    setSelectedIndex(pathToIndex[pathname] ?? undefined);
  }, [pathname]);

  return (
    <List component="nav" sx={{ p: 0, '& .MuiListItemIcon-root': { minWidth: 32 } }}>

      <ListItemButton selected={selectedIndex === 0} onClick={(e) => {
        updatePreferences({ emailOnTimeChange: !settings.emailOnTimeChange }, "emailOnTimeChange")
      }}>

        <ListItemIcon>
          <Timer1 variant="Bulk" size={18} />
        </ListItemIcon>

        <ListItemText primary="Mail on time change" />

        <FormControlLabel
          control={
            <Switch
              size='small'
              checked={settings.emailOnTimeChange}
            />
          }
        />
      </ListItemButton>



      <ListItemButton selected={selectedIndex === 1} onClick={(e) => {
        updatePreferences({ emailOnTrainerAssign: !settings.emailOnTrainerAssign }, "emailOnTrainerAssign")
      }}>
        <ListItemIcon>
          <Profile variant="Bulk" size={18} />
        </ListItemIcon>
        <ListItemText primary="Mail on trainer assignment" />
        <FormControlLabel
          control={
            <Switch
              size='small'
              checked={settings.emailOnTrainerAssign}
            />
          }
        />
      </ListItemButton>


      <ListItemButton selected={selectedIndex === 2} onClick={(event) => handleListItemClick(event, 2)}>
        <ListItemIcon>
          <Lock1 variant="Bulk" size={18} />
        </ListItemIcon>
        <ListItemText primary="Privacy Center" />
      </ListItemButton>
      <Link style={{ textDecoration: 'none' }} target="_blank" href="https://phoenixcoded.authordesk.app/">
        <ListItemButton selected={selectedIndex === 3} onClick={(event) => handleListItemClick(event, 3)}>
          <ListItemIcon>
            <Messages1 variant="Bulk" size={18} />
          </ListItemIcon>
          <ListItemText primary="Feedback" />
        </ListItemButton>
      </Link>
      <ListItemButton selected={selectedIndex === 4} onClick={(event) => handleListItemClick(event, 4)}>
        <ListItemIcon>
          <Clipboard variant="Bulk" size={18} />
        </ListItemIcon>
        <ListItemText primary="History" />
      </ListItemButton>
    </List>
  );
}

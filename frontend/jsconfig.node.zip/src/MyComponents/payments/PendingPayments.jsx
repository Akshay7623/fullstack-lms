import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
  Paper,
  Pagination,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
} from "@mui/material";
import { Stack } from "@mui/system";
import { useEffect, useState } from "react";
import config, { modalStyles, textColor } from "../../config";
import { Modal } from "antd";
import { CloseCircle, TickCircle } from "iconsax-react";
import { setPagination, getPagination } from '../../../pagination';

const dummyData = [
  {
    id: 1,
    trainer: "John Doe",
    topic: "React Basics",
    date: "2024-06-01",
    amount: 2000,
  },
  {
    id: 2,
    trainer: "Jane Smith",
    topic: "Node.js Intro",
    date: "2024-06-03",
    amount: 2500,
  },
  {
    id: 3,
    trainer: "Amit Patel",
    topic: "Python Advanced",
    date: "2024-06-05",
    amount: 3000,
  },
  {
    id: 4,
    trainer: "Sara Lee",
    topic: "UI/UX Design",
    date: "2024-06-07",
    amount: 1800,
  },
  {
    id: 5,
    trainer: "Mohit Sharma",
    topic: "C Programming",
    date: "2024-06-09",
    amount: 2200,
  },
  {
    id: 6,
    trainer: "Emily Clark",
    topic: "SEO Fundamentals",
    date: "2024-06-10",
    amount: 2100,
  },
  {
    id: 7,
    trainer: "Priya Singh",
    topic: "Bootstrap 5",
    date: "2024-06-11",
    amount: 1900,
  },
  {
    id: 8,
    trainer: "Rahul Verma",
    topic: "JavaScript ES6",
    date: "2024-06-12",
    amount: 2300,
  },
  {
    id: 9,
    trainer: "Anjali Mehra",
    topic: "PHP Advanced",
    date: "2024-06-13",
    amount: 2600,
  },
  {
    id: 10,
    trainer: "Vikram Patel",
    topic: "Data Structures",
    date: "2024-06-14",
    amount: 2400,
  },
  {
    id: 11,
    trainer: "Sneha Kapoor",
    topic: "HTML & CSS",
    date: "2024-06-15",
    amount: 1700,
  },
  {
    id: 12,
    trainer: "Rohit Sinha",
    topic: "Django Basics",
    date: "2024-06-16",
    amount: 2800,
  },
  {
    id: 13,
    trainer: "Meera Nair",
    topic: "React Hooks",
    date: "2024-06-17",
    amount: 2100,
  },
  {
    id: 14,
    trainer: "Arjun Rao",
    topic: "Node.js APIs",
    date: "2024-06-18",
    amount: 2500,
  },
  {
    id: 15,
    trainer: "Divya Joshi",
    topic: "Python for Data Science",
    date: "2024-06-19",
    amount: 3200,
  },
  {
    id: 16,
    trainer: "Karan Malhotra",
    topic: "MongoDB Essentials",
    date: "2024-06-20",
    amount: 2000,
  },
  {
    id: 17,
    trainer: "Asha Menon",
    topic: "Express.js",
    date: "2024-06-21",
    amount: 2200,
  },
  {
    id: 18,
    trainer: "Suresh Kumar",
    topic: "Laravel Basics",
    date: "2024-06-22",
    amount: 2700,
  },
  {
    id: 19,
    trainer: "Neha Gupta",
    topic: "Angular Fundamentals",
    date: "2024-06-23",
    amount: 2600,
  },
  {
    id: 20,
    trainer: "Amitabh Roy",
    topic: "Vue.js Introduction",
    date: "2024-06-24",
    amount: 2100,
  },
];

const PAGE_SIZE_OPTIONS = [10, 25, 50, 100];

const PendingPayments = () => {
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(getPagination('pending_payment') || 10);
  const [payments, setPayments] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [totalPage, setTotalPage] = useState(10);


  const handlePageChange = (value) => {
    setPage(value);
    // getPendingPayments(value,pageSize);
  };

  const handlePageSizeChange = (event) => {
    setPageSize(event.target.value);
    setPage(1);
    setPagination('pending_payment', event.target.value);
    //call this after backend integration
    //getPendingPayments(1,event.target.value);
  };

  const getPendingPayments = async (page, pageSize) => {
    const token = localStorage.getItem("token");

    try {
      const url = `${config.hostUrl}/api/pending-payments?page=${page}&pageSize=${pageSize}`;
      const resp = await fetch(url, {
        method: "get",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await resp.json();
      console.log("data is ", data);
    } catch (Err) {
      console.log("Error while fetching data", Err);
      // throw toast error for better user experience
    }
  };

  const settlePayment = async (id) => {
    const token = localStorage.getItem("token");
    console.log("settle payment for id", id);

    setModalOpen(true);
    try {
      const resp = await fetch(`${config.hostUrl}/api/settle-payment`, {
        method: "post",
        body: JSON.stringify({ id: id }),
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      });

      const data = await resp.json();
      console.log(data);
      // call getPendingPayments function with default parameter if response is okay
      // getPendingPayments(page, pageSize);
    } catch (Err) {
      console.log("Err while settling the amount", Err);
      // some custom toast error
    }
  };

  useEffect(() => {
    setPayments(dummyData);
    // call getPendingPayments function after getting data set to state variable
  }, []);

  return (
    <>
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Trainer Name</TableCell>
              <TableCell>Lecture Topic</TableCell>
              <TableCell>Lecture Date</TableCell>
              <TableCell>Amount Due</TableCell>
              <TableCell>Settle</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {payments.length > 0 &&
              payments.map((row) => (
                <TableRow key={row.id}>
                  <TableCell>{row.trainer}</TableCell>
                  <TableCell>{row.topic}</TableCell>
                  <TableCell>{row.date}</TableCell>
                  <TableCell>₹{row.amount.toLocaleString("en-IN")}</TableCell>
                  <TableCell>
                    <Button
                      variant="contained"
                      color="primary"
                      size="small"
                      onClick={() => settlePayment(row.id)}
                    >
                      Settle
                    </Button>
                  </TableCell>
                </TableRow>
              ))}

            <TableRow>
              <TableCell colSpan={3} />
              <TableCell sx={{ fontWeight: "bold" }}>
                Total: ₹
                {payments
                  .reduce((sum, row) => sum + row.amount, 0)
                  .toLocaleString("en-IN")}
              </TableCell>
              <TableCell />
            </TableRow>
          </TableBody>
        </Table>
      </TableContainer>

      <Stack
        direction="row"
        alignItems="center"
        justifyContent="space-between"
        spacing={2}
        sx={{ mt: 2 }}
      >
        <Stack direction="row" alignItems="center" spacing={1}>
          <InputLabel id="per-page-label" sx={{ mb: 0, fontSize: "12px" }}>
            Row per page
          </InputLabel>
          <FormControl size="small" sx={{ minWidth: 50 }}>
            <Select
              labelId="per-page-label"
              value={pageSize}
              onChange={handlePageSizeChange}
            >
              {PAGE_SIZE_OPTIONS.map((size) => (
                <MenuItem key={size} value={size}>
                  {size}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Stack>
        <Pagination
          count={totalPage}
          page={page}
          onChange={(_, value) => handlePageChange(value)}
          color="primary"
          variant="combined"
          showFirstButton
          showLastButton
          sx={{ "& .MuiPaginationItem-root": { my: 0.5 } }}
        />
      </Stack>

      <Modal
        title={
          <span style={{ color: textColor }}>
            Are you sure want to settle payment?
          </span>
        }
        closable={{ "aria-label": "Custom Close Button" }}
        open={modalOpen}
        onCancel={() => setModalOpen(false)}
        styles={modalStyles}
        zIndex={2000}
        footer={[
          <Button
            key="close"
            type="primary"
            endIcon={<TickCircle size={18} />}
            onClick={() => {
              confirmDelete();
            }}
          >
            Confirm
          </Button>,
          <Button
            key="update"
            endIcon={<CloseCircle size={18} />}
            onClick={() => setModalOpen(false)}
          >
            Cancel
          </Button>,
        ]}
      ></Modal>
    </>
  );
};

export default PendingPayments;

// project-imports
// import adminPanel from './admin-panel';
import applications from './applications';
import students from './student';


const menuItems = {
  items: [ students, applications ]
};

export default menuItems;
